package com.example.alansaji.spinnerlist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class listview extends AppCompatActivity {
private TextView apptextview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview);
        apptextview=(TextView) findViewById(R.id.textView);
    }
}
